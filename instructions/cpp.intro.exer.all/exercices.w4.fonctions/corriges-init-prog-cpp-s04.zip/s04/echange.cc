void echange(int& a, int& b)
{
  int copie(a);
  a=b;
  b=copie;
}
