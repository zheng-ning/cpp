#include <iostream>
#include <vector>
using namespace std;

vector<vector<double>> lire_matrice();
void  affiche_matrice(const vector<vector<double>>& M);
vector<vector<double>> multiplication(const vector<vector<double>>& M1, 
                                      const vector<vector<double>>& M2);

// --------------------------------------------------------------------
int main()
{
  vector<vector<double>> M1(lire_matrice()), M2(lire_matrice());

  if (M1[0].size() != M2.size()) {
    cout << "Multiplication de matrices impossible !" << endl;
  } else {
    cout << "Résultat :" << endl;
    affiche_matrice(multiplication(M1, M2));
  }

  return 0;
}

// --------------------------------------------------------------------
vector<vector<double>> lire_matrice()
{
  cout << "Saisie d'une matrice :" << endl;

  unsigned int lignes;
  do {
    cout << "  Nombre de lignes : ";
    cin >> lignes;
  } while (lignes < 1);

  unsigned int colonnes;
  do {
    cout << "  Nombre de colonnes : ";
    cin >> colonnes;
  } while (colonnes < 1);

  vector<vector<double>> M(lignes, vector<double>(colonnes));

  for (unsigned int i(0); i < lignes; ++i) {
    for (unsigned int j(0); j < colonnes; ++j) {
      cout << "  M[" << i+1 << "," << j+1 << "]=";
      cin >> M[i][j];
    }
  }
  return M;
}

// --------------------------------------------------------------------
vector<vector<double>> multiplication(const vector<vector<double>>& M1, 
                                      const vector<vector<double>>& M2)
{
  // crée la Matrice prod à la bonne taille *et* l'initialise
  // avec des zéros :
  vector<vector<double>> prod(M1.size(), vector<double>(M2[0].size()));

  for (size_t i(0); i < M1.size(); ++i)
    for (size_t j(0); j < M2[0].size(); ++j)
      for (size_t k(0); k < M2.size(); ++k)
        prod[i][j] += M1[i][k] * M2[k][j];

  return prod;
}

// --------------------------------------------------------------------
void  affiche_matrice(const vector<vector<double>>& M)
{
  for (auto ligne : M) {
    for (auto element : ligne) {
      cout << element << " ";
    }
    cout << endl;
  }
}
