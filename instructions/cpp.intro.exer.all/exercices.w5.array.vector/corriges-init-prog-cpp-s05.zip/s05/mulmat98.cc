void  affiche_matrice(const vector< vector<double> >& M)
{
  for (unsigned int i(0); i < M.size(); ++i) {
    for (unsigned int j(0); j < M[i].size(); ++j) {
      cout << M[i][j] << " ";
    }
    cout << endl;
  }
}
