#include <iostream>
#include <vector>
#include <string>
using namespace std;

double scalaire(vector<double> u, vector<double> v);
void saisie(const string& titre, vector<double>& vecteur);

int main()
{
  cout << "Quelle taille pour les vecteurs ? ";
  size_t n;
  cin >> n;

  vector<double> v1(n);
  vector<double> v2(n);

  saisie("premier", v1);
  saisie("second",  v2);

  cout << "Le produit scalaire de v1 par v2 vaut " 
       << scalaire(v1, v2) << endl;

  return 0;
}

// --------------------------------------------------------
double scalaire(vector<double> u, vector<double> v)
{
  double somme(0.0);

  for (size_t i(0); i < u.size(); ++i) {
    somme += u[i] * v[i];
  }

  return somme;
}

// --------------------------------------------------------
void saisie(const string& titre, vector<double>& vecteur)
{
  cout << "Saisie du " << titre << " vecteur :" << endl;
  for (size_t i(0); i < vecteur.size(); ++i) {
    cout << " coordonnée " << i+1 << " = ";
    cin >> vecteur[i];
  }
}
