#include <iostream>
#include <cmath>
using namespace std;

constexpr double g(9.81); // la constante de gravité terrestre

int main()
{
  // Saisie des valeurs, avec test de validité ------------
  double eps; // coefficient de rebond de la balle
  do {
    cout << "Coefficient de rebond (0 <= coeff < 1) : ";
    cin >> eps;
  } while ( (eps < 0.0) or (eps >= 1.0) );

  double h0; // hauteur avant rebond
  do {
    cout << "Hauteur initiale      (h0 > 0)         : ";
    cin >> h0;
  } while (h0 <= 0.0);

  int n; // nombre de rebonds à simuler
  do {
    cout << "Nombre de rebonds     (n >= 0)         : ";
    cin >> n;
  } while (n < 0);

  // Declarations -----------------------------------------
  double h1;           // hauteur après le rebond
  double v0, v1;       // vitesses avant et après le rebond

  // Boucle de calcul -------------------------------------
  for (int rebonds(1); rebonds <= n; ++rebonds) {
    // on fait une iteration par rebond
    v0 = sqrt(2.0 * g * h0);   // vitesse avant rebond
    v1 = eps * v0;             // vitesse apres le rebond
    h1 =(v1 * v1) / (2.0 * g); // hauteur après rebond
    h0 = h1;   // qui devient nouvelle haut. avant rebond suivant
  }

  // Affichage du resultat --------------------------------
  cout << "Au " << n
       << "e rebond, la hauteur atteinte est de " << h0 << endl;
  return 0;
}
