#include <iostream>
#include <cmath>
using namespace std;

constexpr double g(9.81); // la constante de gravité terrestre

int main()
{
  // Saisie des valeurs, avec test de validité ------------
  double eps; // coefficient de rebond de la balle
  do {
    cout << "Coefficient de rebond (0 <= coeff < 1) : ";
    cin >> eps;
  } while ( (eps < 0.0) or (eps >= 1.0) );

  double h0; // hauteur avant rebond
  do {
    cout << "Hauteur initiale      (h0 > 0)         : ";
    cin >> h0;
  } while (h0 <= 0.0);

  double h_fin; // hauteur finale
  do {
    cout << "Hauteur finale        (0 < h_fin < h0) : ";
    cin >> h_fin;
  } while ( (h_fin <= 0.0) or (h_fin >= h0) );

  // Declarations -----------------------------------------
  double h1;           // hauteur après le rebond
  double v0, v1;       // vitesses avant et après le rebond
  int rebonds(0);      // nombre de rebonds

  // Boucle de calcul -------------------------------------
  do {
    ++rebonds;                  // une iteration par rebond
    v0 = sqrt(2.0 * g * h0);    // vitesse avant rebond
    v1 = eps * v0;              // vitesse apres le rebond
    h1 = (v1 * v1) / (2.0 * g); // hauteur après rebond
    h0 = h1;   // qui devient nouvelle haut. avant rebond suivant
  } while (h0 > h_fin);

  // Affichage du resultat --------------------------------
  cout << "La balle rebondit " << rebonds
       << " fois avant que la hauteur de rebond (" << h0
       << ") soit inférieure à la limite de " << h_fin << endl;
  return 0;
}
