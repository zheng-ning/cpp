#include <iostream>
using namespace std;

void genereLettre()
{
  cout 
    << "Bonjour chère Mireille,"                                     << endl
    << "Je vous écris à propos de votre cours."                      << endl
    << "Il faudrait que nous nous voyons le 18/12 pour en discuter." << endl
    << "Donnez-moi vite de vos nouvelles !"                          << endl
    << "Amicalement, John."                                          << endl;
}

int main()
{
  genereLettre();
  return 0;
}
